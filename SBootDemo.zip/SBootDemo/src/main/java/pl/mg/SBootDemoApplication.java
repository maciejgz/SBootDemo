package pl.mg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SBootDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SBootDemoApplication.class, args);
    }
}
